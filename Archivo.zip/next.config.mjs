/** @type {import('next').NextConfig} */
const nextConfig = {
    trailingSlash: true, // Para asegurar que las rutas funcionen correctamente
  };
  
  export default nextConfig;